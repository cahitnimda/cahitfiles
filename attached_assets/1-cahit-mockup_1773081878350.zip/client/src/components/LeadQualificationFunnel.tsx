import { Button } from "@/components/ui/button";
import { ArrowRight, Check, Clock, User, Mail, Phone, X } from "lucide-react";
import { useState, useEffect, useCallback, useRef } from "react";

/**
 * Progressive Lead Qualification Funnel - ROBUST VERSION
 * 
 * Design: Once a panel appears (triggered by mouse movement in its section),
 * it stays visible until one of these conditions:
 *   1. The user completes the step (submits the form)
 *   2. The user explicitly closes it via the X button
 *   3. 30 seconds of COMPLETE inactivity (no mouse movement anywhere in section or panel,
 *      no focus on any input) — this is a safety fallback only
 * 
 * The panel will NOT disappear when:
 *   - Mouse moves between section content and the panel
 *   - User clicks on inputs, radio buttons, or any interactive element
 *   - User is typing in any input field
 *   - Mouse briefly leaves the section (generous grace period)
 */

type FunnelStep = 1 | 2 | 3 | 4;

interface ProgressiveFunnelProps {
  currentSection: string;
  onStepComplete: (completedStep: number) => void;
  globalStep: FunnelStep;
  mouseActive: boolean;
  onPanelInteract?: (section: string, interacting: boolean) => void;
  onPanelFocus?: (section: string, focused: boolean) => void;
  onDismiss?: (section: string) => void;
}

const SelectOption = ({
  label,
  selected,
  onClick,
}: {
  label: string;
  selected: boolean;
  onClick: () => void;
}) => (
  <button
    onClick={onClick}
    className={`flex items-center gap-3 w-full text-left px-4 py-3 rounded-lg border-2 transition-all ${
      selected
        ? "border-sky-500 bg-sky-50 text-sky-700 shadow-sm"
        : "border-slate-200 bg-white text-slate-700 hover:border-sky-300 hover:bg-sky-50/50"
    }`}
  >
    <div
      className={`w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-all ${
        selected ? "border-sky-500 bg-sky-500" : "border-slate-300"
      }`}
    >
      {selected && <Check className="w-3 h-3 text-white" />}
    </div>
    <span className="font-medium text-sm">{label}</span>
  </button>
);

const ProgressBar = ({ step }: { step: FunnelStep }) => {
  const progress = step === 4 ? 100 : ((step - 1) / 3) * 100;
  return (
    <div className="mb-5">
      <div className="flex justify-between text-xs text-slate-500 mb-2">
        <span className={step >= 1 ? "text-sky-600 font-semibold" : ""}>Step 1: Needs</span>
        <span className={step >= 2 ? "text-sky-600 font-semibold" : ""}>Step 2: Scope</span>
        <span className={step >= 3 ? "text-sky-600 font-semibold" : ""}>Step 3: Details</span>
      </div>
      <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
        <div
          className="h-full bg-gradient-to-r from-sky-400 to-sky-600 rounded-full transition-all duration-500"
          style={{ width: `${progress}%` }}
        />
      </div>
    </div>
  );
};

export function useProgressiveFunnel() {
  const [globalStep, setGlobalStep] = useState<FunnelStep>(1);
  const [stepCompleted, setStepCompleted] = useState<Record<number, boolean>>({});
  const [heroVisible, setHeroVisible] = useState(false);
  const [expertiseVisible, setExpertiseVisible] = useState(false);
  const [projectsVisible, setProjectsVisible] = useState(false);

  // Use a single ref object for all mutable state to avoid stale closures
  const ref = useRef({
    globalStep: 1 as FunnelStep,
    stepCompleted: {} as Record<number, boolean>,
    // Track whether the panel was dismissed by user (X button)
    dismissed: { hero: false, expertise: false, projects: false } as Record<string, boolean>,
    // Inactivity timeout handles
    inactivityTimeouts: {} as Record<string, ReturnType<typeof setTimeout> | null>,
    // Track if any input in the panel has focus
    inputFocused: { hero: false, expertise: false, projects: false } as Record<string, boolean>,
    // Track last activity timestamp per section
    lastActivity: {} as Record<string, number>,
  });

  // Keep ref in sync with state
  useEffect(() => {
    ref.current.globalStep = globalStep;
    ref.current.stepCompleted = stepCompleted;
  }, [globalStep, stepCompleted]);

  const getStepForSection = (section: string): FunnelStep => {
    if (section === "hero") return 1;
    if (section === "expertise") return 2;
    if (section === "projects") return 3;
    return 1;
  };

  const setVisibility = useCallback((section: string, visible: boolean) => {
    if (section === "hero") setHeroVisible(visible);
    else if (section === "expertise") setExpertiseVisible(visible);
    else if (section === "projects") setProjectsVisible(visible);
  }, []);

  const clearInactivityTimeout = useCallback((section: string) => {
    const t = ref.current.inactivityTimeouts[section];
    if (t) {
      clearTimeout(t);
      ref.current.inactivityTimeouts[section] = null;
    }
  }, []);

  const startInactivityTimeout = useCallback((section: string) => {
    clearInactivityTimeout(section);
    ref.current.inactivityTimeouts[section] = setTimeout(() => {
      // Only hide if no input is focused
      if (!ref.current.inputFocused[section]) {
        setVisibility(section, false);
      } else {
        // If input is focused, restart the timeout
        startInactivityTimeout(section);
      }
    }, 30000); // 30 second inactivity timeout (safety fallback only)
  }, [clearInactivityTimeout, setVisibility]);

  // Record activity and reset inactivity timer
  const recordActivity = useCallback((section: string) => {
    ref.current.lastActivity[section] = Date.now();
    startInactivityTimeout(section);
  }, [startInactivityTimeout]);

  // Called when user explicitly dismisses the panel
  const dismissPanel = useCallback((section: string) => {
    ref.current.dismissed[section] = true;
    clearInactivityTimeout(section);
    setVisibility(section, false);
  }, [clearInactivityTimeout, setVisibility]);

  // Called by the panel component when mouse enters/leaves the panel
  const markPanelInteracting = useCallback((section: string, interacting: boolean) => {
    if (interacting) {
      recordActivity(section);
    }
    // We do NOT hide on mouse leave from panel - only inactivity timeout or explicit dismiss
  }, [recordActivity]);

  // Called by the panel component when an input gets/loses focus
  const markPanelFocused = useCallback((section: string, focused: boolean) => {
    ref.current.inputFocused[section] = focused;
    if (focused) {
      clearInactivityTimeout(section); // Never hide while input is focused
    } else {
      // Restart inactivity timeout when focus leaves
      startInactivityTimeout(section);
    }
  }, [clearInactivityTimeout, startInactivityTimeout]);

  const handleStepComplete = useCallback((completedStep: number) => {
    setStepCompleted(prev => ({ ...prev, [completedStep]: true }));
    ref.current.stepCompleted[completedStep] = true;

    // Reset interaction tracking for the section
    const sections = ["hero", "expertise", "projects"];
    const section = sections[completedStep - 1];
    if (section) {
      ref.current.inputFocused[section] = false;
      clearInactivityTimeout(section);
    }

    if (completedStep === 1) {
      setHeroVisible(false);
      setGlobalStep(2);
      ref.current.globalStep = 2;
      setTimeout(() => {
        document.getElementById("expertise-section")?.scrollIntoView({ behavior: "smooth", block: "start" });
      }, 300);
    } else if (completedStep === 2) {
      setExpertiseVisible(false);
      setGlobalStep(3);
      ref.current.globalStep = 3;
      setTimeout(() => {
        document.getElementById("projects-section")?.scrollIntoView({ behavior: "smooth", block: "start" });
      }, 300);
    } else if (completedStep === 3) {
      setProjectsVisible(false);
      setGlobalStep(4);
      ref.current.globalStep = 4;
    }
  }, [clearInactivityTimeout]);

  // Section mouse move handler - shows the panel
  const createMouseMoveHandler = useCallback((section: string) => {
    return () => {
      const s = ref.current;
      const stepForSection = getStepForSection(section);
      
      // Don't show if wrong step, already completed, or user dismissed it
      if (s.globalStep !== stepForSection || s.stepCompleted[stepForSection] || s.dismissed[section]) return;

      recordActivity(section);
      setVisibility(section, true);
    };
  }, [recordActivity, setVisibility]);

  // Section mouse leave handler - just records that mouse left, does NOT hide
  // The inactivity timeout handles hiding after 30s
  const createMouseLeaveHandler = useCallback((_section: string) => {
    return () => {
      // Intentionally do nothing aggressive here.
      // The panel stays visible. Only the 30s inactivity timeout or explicit dismiss hides it.
    };
  }, []);

  const handleHeroMouseMove = createMouseMoveHandler("hero");
  const handleHeroMouseLeave = createMouseLeaveHandler("hero");
  const handleExpertiseMouseMove = createMouseMoveHandler("expertise");
  const handleExpertiseMouseLeave = createMouseLeaveHandler("expertise");
  const handleProjectsMouseMove = createMouseMoveHandler("projects");
  const handleProjectsMouseLeave = createMouseLeaveHandler("projects");

  // Cleanup
  useEffect(() => {
    return () => {
      Object.values(ref.current.inactivityTimeouts).forEach(t => { if (t) clearTimeout(t); });
    };
  }, []);

  return {
    globalStep,
    heroVisible,
    expertiseVisible,
    projectsVisible,
    handleHeroMouseMove,
    handleHeroMouseLeave,
    handleExpertiseMouseMove,
    handleExpertiseMouseLeave,
    handleProjectsMouseMove,
    handleProjectsMouseLeave,
    handleStepComplete,
    markPanelInteracting,
    markPanelFocused,
    dismissPanel,
  };
}

export default function ProgressiveFunnelPanel({
  currentSection,
  onStepComplete,
  globalStep,
  mouseActive,
  onPanelInteract,
  onPanelFocus,
  onDismiss,
}: ProgressiveFunnelProps) {
  // Step 1 state
  const [projectType, setProjectType] = useState("");
  const [projectGoal, setProjectGoal] = useState("");

  // Step 2 state
  const [projectScale, setProjectScale] = useState("");
  const [timeline, setTimeline] = useState("");
  const [timelineMore, setTimelineMore] = useState("");
  const [budgetAllocated, setBudgetAllocated] = useState("");
  const [budgetMore, setBudgetMore] = useState("");

  // Step 3 state
  const [role, setRole] = useState("");
  const [roleOther, setRoleOther] = useState("");
  const [decisionMaker, setDecisionMaker] = useState("");
  const [decisionMakerOther, setDecisionMakerOther] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [preferredTime, setPreferredTime] = useState("");
  const [customTime, setCustomTime] = useState("");

  const [showThankYou, setShowThankYou] = useState(false);
  const panelRef = useRef<HTMLDivElement>(null);

  const projectTypes = [
    "Marine Construction",
    "Coastal Protection",
    "Seaport Infrastructure",
    "Earthworks",
    "MEP Works",
  ];

  const projectGoals = [
    "Strengthen coastal protection",
    "Expand port capacity",
    "Infrastructure development",
    "Other",
  ];

  const timeSlots = ["8 AM", "9 AM", "10 AM", "11 AM", "1 PM"];

  const handleStep1Submit = () => {
    if (!projectType || !projectGoal) return;
    onStepComplete(1);
  };

  const handleStep2Submit = () => {
    if (!projectScale || !timeline || !budgetAllocated) return;
    onStepComplete(2);
  };

  const handleStep3Submit = () => {
    if (!role || !decisionMaker || !name || !email || !phone) return;
    setShowThankYou(true);
    onStepComplete(3);
  };

  const showStep1 = currentSection === "hero" && globalStep === 1;
  const showStep2 = currentSection === "expertise" && globalStep === 2;
  const showStep3 = currentSection === "projects" && globalStep === 3;

  if (!showStep1 && !showStep2 && !showStep3) return null;

  if (showThankYou && currentSection === "projects") {
    return (
      <div className="absolute right-4 top-1/2 -translate-y-1/2 z-30 w-full max-w-md animate-in fade-in duration-300">
        <div className="bg-white/95 backdrop-blur-md rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
          <div className="bg-gradient-to-r from-green-500 to-emerald-500 px-6 py-4">
            <h3 className="text-white font-bold text-lg">Thank You, {name}!</h3>
            <p className="text-green-100 text-sm">Your consultation is being scheduled</p>
          </div>
          <div className="px-6 py-6 text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Check className="w-8 h-8 text-green-600" />
            </div>
            <p className="text-slate-700 text-sm leading-relaxed">
              Our team will contact you at <strong>{email}</strong> within 24 hours
              to confirm your consultation{preferredTime ? ` at ${preferredTime}` : ""}.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      ref={panelRef}
      className="absolute right-4 top-1/2 -translate-y-1/2 z-30 w-full max-w-md animate-in slide-in-from-right-5 duration-300"
      onMouseEnter={() => onPanelInteract?.(currentSection, true)}
      onMouseLeave={() => onPanelInteract?.(currentSection, false)}
      onFocusCapture={() => {
        onPanelInteract?.(currentSection, true);
        onPanelFocus?.(currentSection, true);
      }}
      onBlurCapture={(e) => {
        // Only mark as unfocused if the new focus target is outside the panel
        const relatedTarget = e.relatedTarget as Node | null;
        if (panelRef.current && relatedTarget && panelRef.current.contains(relatedTarget)) {
          return; // Still inside the panel
        }
        // Small delay to allow click handlers to fire first
        setTimeout(() => {
          onPanelFocus?.(currentSection, false);
        }, 300);
      }}
      onClick={(e) => {
        e.stopPropagation();
        onPanelInteract?.(currentSection, true);
      }}
    >
      <div className="bg-white/95 backdrop-blur-md rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
        {/* Header with dismiss button */}
        <div className="bg-gradient-to-r from-sky-500 to-sky-600 px-6 py-4 flex items-start justify-between">
          <div>
            <h3 className="text-white font-bold text-lg">
              {showStep1 && "Let's Understand Your Needs"}
              {showStep2 && "Project Scope & Timeline"}
              {showStep3 && "Almost There!"}
            </h3>
            <p className="text-sky-100 text-sm">
              {showStep1 && "This helps us direct you to the right service"}
              {showStep2 && "This helps us understand the resources required"}
              {showStep3 && "Share your details for a customized proposal"}
            </p>
          </div>
          <button
            onClick={(e) => {
              e.stopPropagation();
              onDismiss?.(currentSection);
            }}
            className="text-white/70 hover:text-white transition p-1 -mr-1 -mt-1 flex-shrink-0"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="px-6 py-5 max-h-[60vh] overflow-y-auto">
          <ProgressBar step={globalStep} />

          {/* STEP 1 */}
          {showStep1 && (
            <div className="space-y-5">
              <div>
                <label className="block text-sm font-semibold text-slate-800 mb-3">
                  1. What type of project are you planning?
                </label>
                <div className="space-y-2">
                  {projectTypes.map((type) => (
                    <SelectOption
                      key={type}
                      label={type}
                      selected={projectType === type}
                      onClick={() => setProjectType(type)}
                    />
                  ))}
                </div>
                <p className="text-xs text-sky-600 mt-2 italic">
                  This helps us direct you to the right service.
                </p>
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-800 mb-3">
                  2. What is the primary goal of your project?
                </label>
                <div className="space-y-2">
                  {projectGoals.map((goal) => (
                    <SelectOption
                      key={goal}
                      label={goal}
                      selected={projectGoal === goal}
                      onClick={() => setProjectGoal(goal)}
                    />
                  ))}
                </div>
              </div>

              <Button
                onClick={handleStep1Submit}
                disabled={!projectType || !projectGoal}
                className="w-full bg-sky-600 hover:bg-sky-700 text-white font-semibold py-3 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Continue <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
            </div>
          )}

          {/* STEP 2 */}
          {showStep2 && (
            <div className="space-y-5">
              <div>
                <label className="block text-sm font-semibold text-slate-800 mb-3">
                  Is your project:
                </label>
                <div className="space-y-2">
                  {["Small", "Medium", "Large-scale"].map((scale) => (
                    <SelectOption
                      key={scale}
                      label={scale}
                      selected={projectScale === scale}
                      onClick={() => setProjectScale(scale)}
                    />
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-800 mb-3">
                  When do you expect to start construction?
                </label>
                <div className="space-y-2">
                  {["Immediately", "Within 3 months", "6–12 months", "Still in planning"].map(
                    (t) => (
                      <SelectOption
                        key={t}
                        label={t}
                        selected={timeline === t}
                        onClick={() => setTimeline(t)}
                      />
                    )
                  )}
                </div>
                <input
                  type="text"
                  placeholder="More details (optional)"
                  value={timelineMore}
                  onChange={(e) => setTimelineMore(e.target.value)}
                  className="w-full mt-2 px-4 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-sky-400 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-800 mb-3">
                  Has a budget been allocated for this project?
                </label>
                <div className="space-y-2">
                  {["Yes", "Not yet", "Prefer not to say"].map((b) => (
                    <SelectOption
                      key={b}
                      label={b}
                      selected={budgetAllocated === b}
                      onClick={() => setBudgetAllocated(b)}
                    />
                  ))}
                </div>
                <input
                  type="text"
                  placeholder="Approximate budget range (optional)"
                  value={budgetMore}
                  onChange={(e) => setBudgetMore(e.target.value)}
                  className="w-full mt-2 px-4 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-sky-400 focus:border-transparent"
                />
              </div>

              <Button
                onClick={handleStep2Submit}
                disabled={!projectScale || !timeline || !budgetAllocated}
                className="w-full bg-sky-600 hover:bg-sky-700 text-white font-semibold py-3 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Continue <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
            </div>
          )}

          {/* STEP 3 */}
          {showStep3 && (
            <div className="space-y-5">
              <div>
                <label className="block text-sm font-semibold text-slate-800 mb-3">
                  What is your role in this project?
                </label>
                <div className="space-y-2">
                  {["Project owner", "Consultant", "Contractor"].map((r) => (
                    <SelectOption
                      key={r}
                      label={r}
                      selected={role === r}
                      onClick={() => setRole(r)}
                    />
                  ))}
                  <SelectOption
                    label="Other"
                    selected={role === "Other"}
                    onClick={() => setRole("Other")}
                  />
                  {role === "Other" && (
                    <input
                      type="text"
                      placeholder="Please specify your role"
                      value={roleOther}
                      onChange={(e) => setRoleOther(e.target.value)}
                      className="w-full px-4 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-sky-400 focus:border-transparent"
                    />
                  )}
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-800 mb-3">
                  Who will be the main decision-maker?
                </label>
                <div className="space-y-2">
                  {["Myself", "A team", "A client"].map((dm) => (
                    <SelectOption
                      key={dm}
                      label={dm}
                      selected={decisionMaker === dm}
                      onClick={() => setDecisionMaker(dm)}
                    />
                  ))}
                  <SelectOption
                    label="Other"
                    selected={decisionMaker === "Other"}
                    onClick={() => setDecisionMaker("Other")}
                  />
                  {decisionMaker === "Other" && (
                    <input
                      type="text"
                      placeholder="Please specify"
                      value={decisionMakerOther}
                      onChange={(e) => setDecisionMakerOther(e.target.value)}
                      className="w-full px-4 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-sky-400 focus:border-transparent"
                    />
                  )}
                </div>
              </div>

              {/* Contact Details */}
              <div className="bg-sky-50 rounded-xl p-4 border border-sky-100">
                <p className="text-sm font-semibold text-sky-800 mb-3">
                  Share your details for a customized proposal:
                </p>
                <div className="space-y-3">
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input
                      type="text"
                      placeholder="Full Name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-sky-400 focus:border-transparent bg-white"
                    />
                  </div>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input
                      type="email"
                      placeholder="Email Address"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-sky-400 focus:border-transparent bg-white"
                    />
                  </div>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input
                      type="tel"
                      placeholder="Phone Number"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-sky-400 focus:border-transparent bg-white"
                    />
                  </div>
                </div>
              </div>

              {/* Preferred Time */}
              <div>
                <label className="block text-sm font-semibold text-slate-800 mb-2">
                  Best time for your free 20-min consultation?
                </label>
                <div className="flex flex-wrap gap-2 mb-3">
                  {timeSlots.map((slot) => (
                    <button
                      key={slot}
                      onClick={() => setPreferredTime(slot)}
                      className={`px-4 py-2 rounded-lg border-2 text-sm font-medium transition-all flex items-center gap-2 ${
                        preferredTime === slot
                          ? "border-sky-500 bg-sky-50 text-sky-700"
                          : "border-slate-200 text-slate-600 hover:border-sky-300"
                      }`}
                    >
                      <Clock className="w-3.5 h-3.5" />
                      {slot}
                    </button>
                  ))}
                </div>
                <input
                  type="text"
                  placeholder="Or provide a preferred time and day"
                  value={customTime}
                  onChange={(e) => setCustomTime(e.target.value)}
                  className="w-full px-4 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-sky-400 focus:border-transparent"
                />
              </div>

              <Button
                onClick={handleStep3Submit}
                disabled={!role || !decisionMaker || !name || !email || !phone}
                className="w-full bg-sky-600 hover:bg-sky-700 text-white font-semibold py-3 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Submit <Check className="ml-2 w-4 h-4" />
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
